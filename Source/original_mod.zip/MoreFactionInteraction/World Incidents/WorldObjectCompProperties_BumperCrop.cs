﻿using RimWorld;

namespace MoreFactionInteraction.World_Incidents
{
    class WorldObjectCompProperties_BumperCrop : WorldObjectCompProperties
    {
        public WorldObjectCompProperties_BumperCrop()
        {
            this.compClass = typeof(WorldObjectComp_SettlementBumperCropComp);
        }
    }
}
